#!/bin/sh
TASK_EDITOR_DIR=$(CDPATH= cd -P "$(dirname "$0")" && pwd)
/bin/sh "$TASK_EDITOR_DIR/connector/start-ai.sh" "$@"
TASK_EXIT=$?
if [ "$TASK_EXIT" -ne 0 ] && [ -t 0 ]; then printf "\n请查看上方提示。按回车关闭。"; read -r TASK_REPLY; fi
exit "$TASK_EXIT"
